import React, { useState, useEffect } from "react";
import axios from "axios"; // Import Axios
import Sidebar from "../Component/Sidebar";
import "./status.css";

export default function Status() {
  const [data, setData] = useState([]);
  const [startTime, setStartTime] = useState(0);
  const [endTime, setEndTime] = useState(0);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await fetch("/history");
      const jsonData = await response.json();
      setData(jsonData.sensor);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const searchByTimestamp = () => {
    // Chuyển đổi thời gian từ định dạng ngày giờ thành timestamp Unix hoặc định dạng MySQL
    const startTimeUnix = new Date(startTime).getTime() / 1000;
    const endTimeUnix = new Date(endTime).getTime() / 1000;
    console.log(startTimeUnix);
    console.log(endTimeUnix);
    // Gửi yêu cầu tìm kiếm dựa trên khoảng thời gian
    axios.get(`/api/search_data_sensor?startTime=${startTimeUnix}&endTime=${endTimeUnix}`)
      .then(response => {
        // Xử lý dữ liệu tìm kiếm ở đây
        setData(response.data.rows);
        console.log(data);
      })
      .catch(error => console.error(error));
  };

  return (
    <>
      <div className="main_status">
        <Sidebar />
        <div className="status">
          <h1 className="trangthai"> Trạng thái</h1>
          <div className='filter'>
            <label>Từ</label>
            <input type="datetime-local" value={startTime} onChange={(e) => setStartTime(e.target.value)} step="1" />
            <label>Đến</label>
            <input type="datetime-local" value={endTime} onChange={(e) => setEndTime(e.target.value)} step="1" />
            <button onClick={searchByTimestamp}>Tìm kiếm</button>
          </div>
          {/* <input className="selectTime" type=""></input> */}
          <table className="avx">
            <thead>
              <tr>
                <th>id</th>
                <th>name</th>
                <th>status</th>
                <th>Create_at</th>
              </tr>
            </thead>
            <tbody>
              {data.map((item, index) => (
                <tr key={index}>
                  <td>{item.id}</td>
                  <td>{item.name}</td>
                  <td>{item.status}</td>
                  <td>{item.created_at}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}