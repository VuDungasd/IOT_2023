import React, { Fragment, Component, state, useState, useEffect } from "react";
import axios from "axios"; // Import Axios
import Sidebar from "../Component/Sidebar";
import "./sensor.css";

const Sensor = () => {
  const [data, setData] = useState([]);
  const [startTime, setStartTime] = useState(0);
  const [endTime, setEndTime] = useState(0);
  const itemsPerPage = 10;
  const pagefilter = [];

  for (let i = 0; i < data.length; i += itemsPerPage) {
    pagefilter.push(data.slice(i, i + itemsPerPage));
  }

  const [currentPage, setCurrentPage] = useState(0); // Bắt đầu ở trang 0
  const currentData = pagefilter[currentPage]; // Dữ liệu của trang hiện tại

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await fetch("/data_tmp");
      const jsonData = await response.json();
      setData(jsonData.action);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const searchByTimestamp = () => {
    // Chuyển đổi thời gian từ định dạng ngày giờ thành timestamp Unix hoặc định dạng MySQL
    const startTimeUnix = new Date(startTime).getTime() / 1000;
    const endTimeUnix = new Date(endTime).getTime() / 1000;
    console.log(startTimeUnix);
    console.log(endTimeUnix);
    // Gửi yêu cầu tìm kiếm dựa trên khoảng thời gian
    axios.get(`/api/search_data?startTime=${startTimeUnix}&endTime=${endTimeUnix}`)
      .then(response => {
        // Xử lý dữ liệu tìm kiếm ở đây
        setData(response.data.rows);
        console.log(data);
      })
      .catch(error => console.error(error));
  };

  return (
    <>
      <div className="main_sensor">
        <Sidebar />
        <div className="table_sensor">
          <h1 className="trangthai"> Dữ liệu từ sensor</h1>
          <div className='filter'>
            <label>Từ</label>
            <input type="datetime-local" value={startTime} onChange={(e) => setStartTime(e.target.value)} step="1" />
            <label>Đến</label>
            <input type="datetime-local" value={endTime} onChange={(e) => setEndTime(e.target.value)} step="1" />
            <button onClick={searchByTimestamp}>Tìm kiếm</button>
          </div>
          <table className="avx">
            <thead>
              <tr>
                <th>id</th>
                <th>nhiet do</th>
                <th>Độ ẩm</th>
                <th>ánh sáng</th>
                <th>thời gian</th>
              </tr>
            </thead>
            <tbody>
              {currentData ? (
                currentData.length > 0 ? (
                  currentData.map((item, index) => (

                    <tr key={index}>
                      <td>{item.id}</td>
                      <td>{item.temperature}</td>
                      <td>{item.humidity}</td>
                      <td>{item.light}</td>
                      <td>{item.created_at}</td>
                    </tr>

                  ))
                ) : (
                  <tr>
                    <td colSpan="4">Không tìm thấy kết quả</td>
                  </tr>
                )
              ) : (
                data.map((item, index) => (
                  <tr key={index}>
                    <td>{item.id}</td>
                    <td>{item.temperature}</td>
                    <td>{item.humidity}</td>
                    <td>{item.light}</td>
                    <td>{item.created_at}</td>
                  </tr>
                ))
              )}

            </tbody>
          </table>
          <button onClick={() => setCurrentPage(currentPage - 1)} disabled={currentPage === 0}>Trang trước</button>
          <button onClick={() => setCurrentPage(currentPage + 1)} disabled={currentPage === pagefilter.length - 1}>Trang tiếp theo</button>

        </div>
      </div>
    </>
  );
};


export default Sensor;