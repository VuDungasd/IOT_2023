import React, { Fragment, useEffect, useState } from "react";
import Sidebar from "../../Component/Sidebar";
import HomeRightBar from "../../Component/HomeRightBar/HomeRightBar";
import "./home.css";

export default function Home() {

    return (
        <>
            <div className="MainHomeContainer">
                <Sidebar />
                <HomeRightBar></HomeRightBar>
            </div>
        </>
    );
}
