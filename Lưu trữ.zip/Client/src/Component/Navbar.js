import React, {Fragment} from "react";
import "./navbar.css";

export default function Navbar(){
    return(
        <div className="MainNavbarContainer">
            <div className="dashboardContainer">
                <h1 className="dashtext">Dashboard</h1>
            </div>

            <div className="ProfileItemsContainer">
                <img src={require('./Icons/pngwing.com.png')} className="NotificationIcon" alt=""></img>
                <div className="profileItem">
                    <img src={require('./Icons/VUDUNG.jpeg')} className="ProfileIcon"></img>
                    <p className="ProfileText">Huy Dang</p>

                </div>
            </div>
        </div>
    )
}