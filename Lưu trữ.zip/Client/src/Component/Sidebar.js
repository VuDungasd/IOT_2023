import React, { Component } from "react";
import "./sidebar.css";
import { Link } from "react-router-dom";

export default function Sidebar() {
  return (
    <div className="mainSidebarContainer">
      <nav>
        {/* <div className="adminContainer">
                    <h1 className="adminText">Admin</h1>
                </div> */}

        <ul className="ulContainer">
          <h2 className="menu">Menu</h2>
          <Link style = {{textDecoration: 'none'}} to={"/home"} >
            <li className="liContainer">
              <img src={require("./Icons/analysis.png")}
                className="sidebaricons"
                alt="anh"
              />
              <p className="itemNames">Dashboard</p>
            </li>
          </Link>
          <Link style={{textDecoration: 'none'}} to="/sensor" Component>
            <li className="liContainer">
              <img
                src={require("./Icons/DailyTask.png")}
                className="sidebaricons"
                alt="anh"
              />
              <p className="itemNames">History</p>
            </li>
          </Link>

          {/* <Link style={{textDecoration: 'none'}} to="/user" Component>
            <li className="liContainer">
              <img src={require("./Icons/settings1.png")} className="sidebaricons" alt="" />
              <p className="itemNames">User</p>
            </li>
          </Link> */}

          <Link style={{textDecoration: 'none'}} to="/status" Component>
            <li className="liContainer">
              <img src={require("./Icons/analysis.png")} className="sidebaricons" alt="" />
              <p className="itemNames">ActionStatus</p>
            </li>
          </Link>
        </ul>
      </nav>
    </div>
  );
}
