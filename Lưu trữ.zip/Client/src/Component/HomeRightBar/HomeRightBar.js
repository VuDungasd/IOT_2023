import React, { useEffect, useState } from "react";
import axios from "axios"; // Import Axios
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import "./homerightbar.css";
import Navbar from "../Navbar";

export default function HomeRightBar() {
  const [data, setData] = useState([]);
  const temperaturecolor = `hsl(${255 - 5 * (data.length > 0 ? data[data.length - 1].temperature : 0)}, 100%, 50%)`;
  const humicolor = `hsl(220, 100%, ${50 + ((data.length > 0 ? data[data.length - 1].humidity : 0)-20)/3 }%)`;
  const lightcolor = `hsl(220, 100%, ${((data.length > 0 ? data[data.length - 1].light : 0)) / 10}%)`;

  // Hàm gửi trạng thái đèn qua MQTT
  const sendLightStatusToMQTT = (status) => {
    sendLightStatusToServer(status); // Sau khi gửi qua MQTT, gửi trạng thái đèn đến máy chủ
  };

  // Hàm gửi trạng thái đèn đến máy chủ bằng Axios
  const sendLightStatusToServer = (status) => {
    axios
      .post("/api/updateLightStatus", { status })
      .then((response) => {
        console.log(response.data);
      })
      .catch((error) => {
        console.error("Error sending light status to server:", error);
      });
  };

  // gui trang thai quat qua server
  const sendFanStatusToMQTT = (status) => {
    sendFanStatusToServer(status);
  }
  // gui den may chu bang axios
  const sendFanStatusToServer = (status) => {
    axios
      .post("/api/updateFanStatus", { status })
      .then((response) => {
        console.log(response.data);
      })
      .catch((error) => {
        console.error("Error sending light status to server:", error);
      });
  };


  // lấy sự kiện onl off của quạt và đèn by VD 
  const [isLightOn, setIsLightOn] = useState(false);
  const [isFanOn, setIsFanOn] = useState(false);

  // code tự giải thích

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      fetchData();
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const fetchData = async () => {
    try {
      const response = await fetch("/data_tmp");
      const jsonData = await response.json();
      setData(jsonData.action.reverse());
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    sendLightStatusToMQTT(isLightOn);
  }, [isLightOn]);

  useEffect(() => {
    sendFanStatusToMQTT(isFanOn);
  }, [isFanOn]);

  const [countBat, setCountBat] = useState(0);
  const [countTat, setCountTat] = useState(0);

  useEffect(() =>{
    fetchOn();
  }, [isLightOn]);
  const fetchOn = async () => {
    try {
      const response = await fetch("/count_led_on");
      const jsonData = await response.json();
      setCountBat(jsonData.rows[0].count);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  }

  useEffect(() =>{
    fetchOff();
  }, [isLightOn]);
  const fetchOff = async () => {
    try {
      const response = await fetch("/count_led_off");
      const jsonData = await response.json();
      setCountTat(jsonData.rows[0].count);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  }

  return (
    <>
      <div className="mainHomeRightbar">
        <Navbar />
        <div>
          <div className="ItemContainer">
            <div className="ItemContainer1">
              <div className="subitemContainer">
                <p className="taskProgress">Nhiệt độ hiện tại</p>
                <p className="taskCounter1" style={{color : temperaturecolor}}>{data.length > 0 ? data[data.length - 1].temperature : 0}°C</p>
                <p className="currentMonth1">Current Month</p>
              </div>

              <div className="lineChartContainer">
                {/* <h1>Biểu đồ LineChart</h1> */}
                <ResponsiveContainer width="100%" height={100}>
                  <LineChart data={data} margin={{ top: 20, right: 10, left: 0, bottom: 0 }} >
                    {/* <XAxis dataKey='date' ticks={evenlyDistributedDates} /> */}
                    <YAxis />
                    <CartesianGrid strokeDasharray='3 3' />
                    <Tooltip />
                    {/* <Legend /> */}
                    <Line type='monotone' dataKey='temperature' stroke='#001529' activeDot={{ r: 10 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="ItemContainer1">
              <div className="subitemContainer">
                <p className="taskProgress">Độ ẩm hiện tại</p>
                <p className="taskCounter2" style={{color : humicolor}}>{data.length > 0 ? data[data.length - 1].humidity : 0}%</p>

                <p className="currentMonth1">Current Month</p>
              </div>
              <div className="barchartContainer">
                <BarChart width={160} height={100} data={data}>
                  <Tooltip />
                  <Bar dataKey="humidity"
                    fill="green"
                  />
                </BarChart>
              </div>
            </div>
            <div className="ItemContainer1">
              <div className="subitemContainer3">
                <p className="taskProgress3">Cường độ ánh sáng</p>
                {/* <p className="taskCounter3"> */}
                <p className="taskCounter3" style={{color : lightcolor}} > {data.length > 0 ? data[data.length - 1].light : 0} lux</p>
                {/* </p> */}
              </div>
            </div>
          </div>
        </div>

        <div className="MidAnalysis">
          <div className="MiddleTaskChart">
            <p className="TaskCretedvsCompleted">taskCounter1</p>
            <ResponsiveContainer width="93%" height={328}>
              <LineChart
                data={data}
                margin={{ top: 20, right: 10, left: 0, bottom: 20 }}
              >
                <XAxis dataKey="time" />
                <YAxis />
                <CartesianGrid strokeDasharray="3 3" />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="temperature"
                  stroke="#FF0000"
                  name="Temperature (°C)"
                />
                <Line
                  type="monotone"
                  dataKey="humidity"
                  stroke="#00FF00"
                  name="Humidity (%)"
                />
                <Line
                  type="monotone"
                  dataKey="light"
                  stroke="#0000FF"
                  name="Light (lux)"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="TaskContainer">
            <div className="TaskItem1">
              <div className="TaskChart">
                <img
                  src={require("../Icons/air_tag.png")}
                  className={`airTaskChart ${isFanOn ? "rotate" : ""}`}
                  alt=""
                />
                <div className="button1">
                  <label className="switch">
                    <input type="checkbox" id="togBtn" checked={isFanOn} onChange={() => setIsFanOn(a => !a)} />
                    <div className="slider round">
                      {/* <!--ADDED HTML --> */}
                      <span className='on'>ON</span>
                      <span className='off'>OFF</span>
                      {/* <!--END--> */}
                    </div>
                  </label>
                </div>
              </div>
              <div className="MonthlyEarning"></div>
            </div>

            <div className="TaskItem2">
              <div className="TaskChart">
                <p>So lan bat den: {countBat} </p>
                <p>So lan tat den: {countTat} </p>
                <p>Đèn led: {isLightOn ? 'ON' : 'OFF'}</p>

                {/* {console.log(isLightOn)} */}
                <div className="button2">
                  <label className="switch">
                    <input type="checkbox" id="togBtn2" checked={isLightOn} onChange={() => setIsLightOn(prevState => !prevState)} />
                    <div className="slider round">
                      {/* <!--ADDED HTML --> */}
                      <span className="on">ON</span>
                      <span className="off">OFF</span>
                      {/* <!--END--> */}
                    </div>
                  </label>
                </div>

              </div>
              <div className="MonthlyEarning"></div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}