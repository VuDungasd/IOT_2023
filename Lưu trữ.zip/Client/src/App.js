// import logo from './logo.svg';
// import './App.css';

import ReactDOM from "react-dom/client";
import React, {
  Fragment,
  useEffect,
  useInsertionEffect,
  useState,
  userState,
} from "react";
import Home from "./Page/Home/Home";
import { BrowserRouter, Routes, Route, Router } from "react-router-dom";
import Sensor from "./Page/Sensor";
import Status from "./Page/Status";

function App() {
  const [backendData, setBackendData] = useState([{}]);
  useEffect(() => {
    fetch("/api")
      .then((response) => response.json())
      .then((data) => {
        setBackendData(data);
      });
  }, []);
  return (
    <>
        <Routes>
          <Route path="/Home" element={<Home/>} ></Route>
          <Route path="/sensor" element={<Sensor/>} />
          <Route path="/status" element={<Status/>} />
          <Route exact path='/' element={<Home/>}/>
          
        </Routes>

      {/* <Home></Home> */}
    </>
  );
}
// const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render(<App />);
export default App;
